# springfox-example
Example project implementing Swagger rest documentation using SpringFox.
