package com.agneinheaven.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.*;

@ApiModel(description = "Class representing a person tracked by the application.")
public class Task {
    @NotNull
    @ApiModelProperty(notes = "${task.id}", example = "1", required = true, position = 0)
    private int id;

    @NotBlank
    @Size(min = 1, max = 20)
    @ApiModelProperty(notes = "${task.name}", example = "Computing", required = true, position = 1)
    private String name;

    @NotBlank
    @Min(0)
    @Max(100)
    @ApiModelProperty(notes = "${task.time}", example = "24", required = true, position = 2)
    private int time;

    @NotBlank
    @Size(min = 1, max = 20)
    @ApiModelProperty(notes = "${task.group}", example = "IT", required = true, position = 3)
    private String group;
    
    @NotBlank
    @Size(min = 1, max = 20)
    @ApiModelProperty(notes = "${task.asignee}", example = "Mina", required = true, position = 4)
    private String asignee;
    
    @NotBlank
    @Size(min = 0, max = 6)
    @ApiModelProperty(notes = "${task.subtask}", example = "0", required = true, position = 5)
    private int subtask;

    @NotBlank
    @ApiModelProperty(notes = "${task.finished}", example = "false", required = true, position = 6)
    private boolean finished;
    
    public Task() {
    }

    public Task(int id, String name, int time, String group, String asignee, int subtask, boolean finished) {
        this.id = id;
        this.name = name;
        this.time = time;
        this.group = group;
        this.asignee = asignee;
        this.subtask = subtask;
        this.finished = finished;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getAsignee() {
		return asignee;
	}

	public void setAsignee(String asignee) {
		this.asignee = asignee;
	}

	public int getSubtask() {
		return subtask;
	}

	public void setSubtask(int subtask) {
		this.subtask = subtask;
	}

	public boolean isFinished() {
		return finished;
	}

	public void setFinished(boolean finished) {
		this.finished = finished;
	}

}