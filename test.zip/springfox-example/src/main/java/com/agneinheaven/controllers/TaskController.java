package com.agneinheaven.controllers;

import com.agneinheaven.domain.Task;
import com.agneinheaven.services.TaskService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v2/tasks/")
@Api(description = "Set of endpoints for Creating, Retrieving, Updating and Deleting of Tasks.")
public class TaskController {

    private TaskService taskService;

    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    @ApiOperation("${taskcontroller.getalltasks}")
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

    @RequestMapping(method = RequestMethod.GET, path = "/{id}", produces = "application/json")
    @ApiOperation("${taskcontroller.gettaskbyid}")
    public Task getTaskById(@ApiParam("Id of the task to be obtained. Cannot be empty.")
                                    @PathVariable int id) {
        return taskService.getTaskById(id);
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/{id}")
    @ApiOperation("${taskcontroller.deletetask}")
    public void deleteTask(@ApiParam("Id of the task to be deleted. Cannot be empty.")
                                 @PathVariable int id) {
       taskService.deleteTask(id);
    }

    @RequestMapping(method = RequestMethod.POST, produces = "application/json")
    @ApiOperation("${taskcontroller.createtask}")
    public Task createTask(@ApiParam("Person information for a new person to be created.")
                                   @RequestBody Task task) {
        return taskService.createTask(task);
    }
    
    @Autowired
    public void setTaskService(TaskService taskService) {
        this.taskService = taskService;
    }
    
    @RequestMapping(value = "/task/{id}", method = RequestMethod.PUT)
    @ApiOperation("${taskcontroller.updatetask}")
    public ResponseEntity<?> updateTask(@PathVariable("id") long id, @RequestBody Task task) {
        Task currentTask = taskService.getTaskById(id);
 
        currentTask.setName(task.getName());
        currentTask.setTime(task.getTime());
        currentTask.setGroup(task.getGroup());
        currentTask.setAsignee(task.getAsignee());
        currentTask.setSubtask(task.getSubtask());
        //currentTask.setFinished(task.isFinished());
 
        taskService.updateTask(currentTask);
        return new ResponseEntity<Task>(currentTask, HttpStatus.OK);
    }
}