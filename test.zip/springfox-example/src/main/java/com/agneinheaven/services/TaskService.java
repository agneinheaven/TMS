package com.agneinheaven.services;

import org.springframework.stereotype.Service;

import com.agneinheaven.domain.Task;

import javax.annotation.PostConstruct;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;

@Service
public class TaskService {

    private List<Task> tasks;

    @PostConstruct
    void init() {
        this.tasks = new ArrayList<>();
        
        Task task1 = new Task(1, "Computing", 24, "IT", "Mina", 6, giveStatus(6));
        tasks.add(task1);
        Task task2 = new Task(2, "Computing2", 24, "IT", "Mina", 4, giveStatus(4));
        tasks.add(task2);
        
        for (int j = 0; j < tasks.size(); j++) {
        	Task task = tasks.get(j);
        	if(task.getSubtask() == 6) {
        		System.out.println(task.getName() + " DONE" );
        	}
        	else {
        		System.out.println(task.getName() + " Waiting..." );
        	}
        }
        
    }
        
    public void updateTask(Task task) {
		int index = tasks.indexOf(task);
		tasks.set(index, task);
	}
    
    public List<Task> getAllTasks() {
        return this.tasks;
    }

    public Task getTaskById(long id) {
        return this.tasks
                .stream()
                .filter(task -> task.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public Task createTask(Task task) {
        OptionalInt maxId = this.tasks.stream().mapToInt(Task::getId).max();
        if (maxId.isPresent()) {
           task.setId(maxId.getAsInt()+1);
        }

        return task;
    }

    public void deleteTask(int id) {
        for (Task task : this.tasks) {
            if(task.getId() == id) {
                this.tasks.remove(task);
                return;
            }
        }
    }
    
   
    public boolean giveStatus(int x) {
    	if (x == 6) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    	
}
